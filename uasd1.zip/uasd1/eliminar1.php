<?php 
include("bd1.php");

if (isset($_GET['id'])) {

    $id = $_GET['id'];
    $resultados = Conexion::consultar("DELETE FROM asignaturas WHERE id=$id");
    //$query = "DELETE FROM tasks WHERE id = $id";
    //$result = new mysqli_query($conexion, $query);
    #if (!$resul) {
     #   die("Query Failed");
    #}
    $_SESSION['message'] = 'asignaturas Remove Successfully';
    $_SESSION['message_type'] = 'danger';
      header("Location: aulas.php"); 
}else{
    header('location:aulas.php');
}
?>