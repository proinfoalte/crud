<?php

include("bd1.php");


if (isset($_POST['Guardar'])){
    
    extract($_POST);    
    if(!empty ($MATERIA && $COORDINADOR && $DOCENTE && $MATERIA_COMPLETA && $MATERIA_INCOMPLETA)){
        #Conexion::consultar("INSERT INTO asignaturas(id,materia, facultad, coordinador, promocion, grupo)
        #VALUES(null,'$MATERIA', '$FACULTAD', '$COORDINADOR', null, '$GRUPO')");

        Conexion::ingresar($MATERIA, $COORDINADOR, $DOCENTE, $MATERIA_COMPLETA, $MATERIA_INCOMPLETA);

        $_SESSION['message'] = 'Guardo con Exito';
        $_SESSION['message_type'] = 'success';
        header("Location: aulas.php");
    }else{
        $_SESSION['message'] = 'Campos Vacios';
        $_SESSION['message_type'] = 'warning';
        header("Location: aulas.php");
    }

}



?>